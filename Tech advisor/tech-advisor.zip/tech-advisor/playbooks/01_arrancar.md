# Playbook 01 — ARRANCAR proyecto nuevo

**Cuándo usar:** el usuario dice "quiero hacer X", "voy a construir Y", "estoy pensando en Z", o llega con una idea sin plan.

**Tiempo target:** 5-10 min con el usuario. Si tarda más, está procrastinando o no tiene claridad real (ambas cosas hay que llamar).

**Output esperado al cerrar:**
- Arquetipo identificado
- Stack elegido con justificación
- Top 3 riesgos concretos
- Estrategia de testing mínima
- 3 próximos pasos concretos
- Decisión GO / NO-GO

---

## Paso 0 — Filtro brutal (responde antes de seguir)

1. ¿Qué problema concreto resuelves? (1 frase, sin jerga)
2. ¿Quién lo usa? (persona real, nombre si es posible)
3. ¿Qué pasa si NO lo construyes? (si la respuesta es "nada", para acá)
4. ¿Por qué AHORA? (¿es urgente o es ansiedad?)

Si las 4 no se responden claro → **STOP.** Vuelve cuando sí.

---

## Paso 1 — Las 10 preguntas críticas (cierre de scope)

Responde sí/no/dato. Si dudas, escribe "no sé" — eso ya es señal.

| # | Pregunta | Respuesta |
|---|----------|-----------|
| 1 | ¿Es para uso personal, equipo pequeño, o producto público? | |
| 2 | ¿Hay 1 usuario o N usuarios concurrentes? | |
| 3 | ¿Maneja datos sensibles (PII, credenciales, dinero)? | |
| 4 | ¿Necesita persistencia o es stateless? | |
| 5 | ¿Tiene UI o es solo backend/CLI? | |
| 6 | ¿Depende de servicios externos (APIs, LLMs, DBs)? | |
| 7 | ¿Latencia tolerable: <100ms / <1s / <10s / no importa? | |
| 8 | ¿Cuánto tiempo real le vas a dedicar esta semana? (horas) | |
| 9 | ¿Lo vas a mantener tú solo o alguien más lo va a tocar? | |
| 10 | ¿Existe ya algo que haga esto? (¿por qué no usarlo?) | |

**Regla:** Si la #10 tiene respuesta y no es razón fuerte → reconsidera. No reinventes.

---

## Paso 2 — Identifica el arquetipo

Marca el que mejor encaje. Solo uno principal (puede tener uno secundario).

| Arquetipo | Cuándo aplica | Ejemplo |
|-----------|--------------|---------|
| **CLI** | Herramienta de línea de comandos, uso local o terminal | Adly CLI, git, ffmpeg |
| **API/Servicio** | HTTP endpoints, consumido por otros sistemas | FastAPI backend, REST/GraphQL |
| **Agent (LLM)** | Llama LLMs, decide acciones, multi-paso | Adly engine, agentes ReAct |
| **Pipeline** | Procesa datos batch o streaming, ETL/ELT | Scraping, transformación CSV |
| **Web App** | UI en navegador, frontend + backend | Dashboard, SaaS |
| **Game** | Loop de render + input + state | Tetris, snake |
| **Library** | Código que otros importan, sin runtime propio | utility package |
| **Embedded/Script** | Ejecutable corto, una sola tarea | scripts de mantenimiento |

→ Una vez identificado, consulta `07_patterns_library.md` sección del arquetipo correspondiente para stack + patrones obligatorios + estructura.

---

## Paso 3 — Riesgos top 3 reales

No copies de una lista. Piensa los 3 más probables PARA TU CASO. Lista guía:

- **CLI:** dependencias OS-specific, parsing frágil, estado en archivos sin lock
- **API:** input sin validar → injection, sin rate limit → abuse, errores filtran info
- **Agent:** rate limits provider, costos descontrolados, prompt injection, sin fallback
- **Pipeline:** datos sucios rompen todo, runs duplicados, falla silenciosa
- **Web App:** XSS, CSRF, leaks por permisos mal puestos, performance mobile
- **Game:** memory leaks, frame drops, input lag
- **Library:** breaking changes, dependency hell
- **Script:** corre 2 veces y rompe algo, sin logs = debug imposible

---

## Paso 4 — Testing strategy mínima

| Arquetipo | Qué testear sí o sí |
|-----------|---------------------|
| CLI | Cada comando con input válido + inválido + edge case. Snapshot output. |
| API | Cada endpoint: 200 happy + 4xx validación + 5xx simulado. Auth si aplica. |
| Agent | **ReliabilityBench 3D:** consistency, robustness, fault tolerance. Chaos: timeout, rate limit, response malformado. |
| Pipeline | Schema in/out, idempotencia, dato sucio. |
| Web App | E2E del flujo principal. Auth/permisos. |
| Game | Game loop a distintos FPS, input edge cases. |
| Library | Public API completa. Edge cases documentados. |
| Script | Smoke test: ¿corre sin error? |

**No testees todo.** Testea lo que rompería al usuario si falla.

---

## Paso 5 — Checklist de inicio (antes del primer commit)

- [ ] Repo creado con `.gitignore` correcto para el stack
- [ ] README con: qué es, cómo correrlo, cómo testearlo (3 secciones, 10 líneas)
- [ ] Estructura de carpetas creada según arquetipo
- [ ] Dependencias en archivo de lock (`requirements.txt`, `package-lock.json`, `Cargo.lock`)
- [ ] Variables sensibles en `.env`, `.env.example` versionado
- [ ] Logging configurado desde el inicio (no `print`)
- [ ] Un test que corra y pase (aunque sea trivial — valida el setup)
- [ ] Decidiste cómo se va a correr en local (un comando)

Si te falta más de 2 → **no codees lógica todavía.** Termina el setup.

---

## Paso 6 — GO / NO-GO inicial

| Pregunta | Sí | No |
|----------|----|----|
| ¿Tienes claro arquetipo + arquitectura? | | |
| ¿Identificaste 3 riesgos concretos? | | |
| ¿Sabes qué vas a testear? | | |
| ¿Setup inicial completo (paso 5)? | | |
| ¿Tienes tiempo real esta semana para avanzar? | | |

**Todos sí → GO.** Codea.
**Algún no → NO-GO.** Resuélvelo antes.

---

## Cierre del playbook

Antes de dejar al usuario, asegúrate de entregar:

1. **Arquetipo:** _______
2. **Stack:** _______
3. **Top 3 riesgos:** _______
4. **Testing strategy:** _______
5. **Próximos 3 pasos concretos:** _______

Si NO tienes esto → no terminaste. No le sueltes "arranca".

---

## Anti-patrón a vigilar

Si el usuario lleva >3 sesiones de "voy a empezar X" sin haber escrito una línea de código → no es problema de validación, es resistencia / miedo / falta de claridad real. Llámalo. No le des otro plan; mándalo a codear el primer pedazo MÍNIMO ya.
