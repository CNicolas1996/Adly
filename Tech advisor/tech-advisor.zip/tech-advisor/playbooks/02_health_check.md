# Playbook 02 — HEALTH CHECK del proyecto en curso

**Cuándo usar:** el usuario dice "¿cómo voy?", "siento que ando perdido", "¿estoy en scope creep?", "no sé si esto avanza", o lleva semanas en algo y duda del rumbo.

**Tiempo target:** 10-15 min. Diagnóstico, no terapia. Salida concreta.

**Output esperado:**
- Estado actual honesto (semáforo verde/amarillo/rojo)
- 2-3 problemas concretos identificados
- Decisión: continuar / pivotar / pausar / matar
- Plan de los próximos 7 días

---

## Paso 0 — Recordar el origen

Antes de evaluar dónde está, recuerda dónde dijo que iba.

1. ¿Cuál era el problema original que querías resolver? (en 1 frase)
2. ¿Quién era el usuario?
3. ¿Qué prometiste entregar y para cuándo?
4. ¿Cuántas semanas/días llevas en esto?

Si no recuerdas claro algo de esto → señal #1: el proyecto ya perdió foco. Hay que pararlo y reanclar antes de seguir.

---

## Paso 1 — Foto del estado actual

Responde sin maquillar:

| Pregunta | Respuesta cruda |
|----------|----------------|
| ¿Hay un usuario real usándolo? | sí / no / "lo va a usar pronto" (= no) |
| Última vez que un usuario real lo tocó | hace X días |
| % de lo prometido entregado | __% |
| Tests pasan localmente | sí / no / "no he corrido" |
| ¿Sabes cómo deployarlo si tocara hoy? | sí / no |
| Última semana: ¿qué entregaste concretamente? | (lista) |
| Esta semana: ¿qué TOCA entregar? | (lista) |
| Bloqueos activos | (lista) |

Si respuesta a "¿qué entregaste la semana pasada?" es vaga ("avancé en X", "estuve trabajando en Y") sin nada concreto → señal #2: no hay output medible.

---

## Paso 2 — Detector de scope creep

Marca todas las que apliquen:

- [ ] Empecé features que no estaban en el plan original
- [ ] He cambiado el stack/framework principal en el camino
- [ ] Estoy "preparando para escalar" pero no tengo ni 1 user
- [ ] Llevo más tiempo en infra/herramientas que en producto
- [ ] He reescrito algo que ya funcionaba "porque no me gustaba"
- [ ] El alcance original cambió >30% sin decisión consciente
- [ ] Hay >1 "side project dentro del proyecto" (algo que empecé y no terminé)
- [ ] Estoy aprendiendo una tech nueva mientras construyo esto serio

**Conteo:**
- 0-1 ✅ Estás OK
- 2-3 ⚠️ Scope creep moderado, hay que cortar
- 4+ 🚨 Efecto Chavo activo, hay que parar y reanclar

---

## Paso 3 — Detector de drift de plan

¿Estás haciendo lo que dijiste que harías?

| Aspecto | Plan original | Realidad hoy | Drift |
|---------|---------------|--------------|-------|
| Feature principal | | | |
| Usuario target | | | |
| Stack/tech | | | |
| Timeline | | | |
| Calidad mínima | | | |

Si hay drift en ≥2 aspectos → necesitas decisión consciente: ¿el plan estaba mal o estás dispersándote?

---

## Paso 4 — Diagnóstico de salud técnica

Sin abrir código, responde:

- [ ] ¿Tienes deuda técnica crítica documentada? (sin tests core, sin manejo errores frontera, credenciales en código)
- [ ] ¿Hay funciones que ya nadie entiende (incluido tú)?
- [ ] ¿Has hecho >5 commits con mensajes "wip" / "fix" / "stuff" en la última semana?
- [ ] ¿Tienes ramas viejas sin mergear / mergeadas y no borradas?
- [ ] ¿Hay TODOs sin tracking?
- [ ] ¿La última vez que corriste tests fue hace >1 semana?

**Conteo:**
- 0-1 ✅ Salud técnica decente
- 2-3 ⚠️ Empieza a oler
- 4+ 🚨 El proyecto está pudriéndose, refactor antes de features

---

## Paso 5 — Diagnóstico de motivación / energía

Esto importa. Proyectos zombies matan más que bugs:

1. Cuando piensas en abrir el editor para este proyecto, ¿qué sientes? (energía / neutro / pereza / ansiedad)
2. ¿Hablas del proyecto con orgullo o lo evades en conversaciones?
3. ¿Lo abres por inercia o por decisión?
4. Si te dijeran "puedes matarlo sin culpa", ¿lo harías?

Si las respuestas son malas → no es problema técnico, es proyecto sin alma. Considerar matar > seguir penando.

---

## Paso 6 — Decisión

Con todo lo anterior, decide UNA de las 4:

### A. ✅ CONTINUAR
- Health técnico OK
- Scope estable
- Motivación viva
- → Plan de los próximos 7 días con 1 entregable concreto

### B. 🔄 PIVOTAR
- Drift de plan claro pero hay valor en lo construido
- Cambio consciente de scope o usuario o feature principal
- → Reescribe plan original. Documenta qué cambió y por qué. Luego continúa con plan nuevo.

### C. ⏸️ PAUSAR
- No hay urgencia real
- Otro proyecto pesa más
- Falta claridad o energía
- → Documenta estado actual en BITACORA. Cierra ramas. Define condición para retomar (NO fecha vacía: "cuando tenga X").

### D. ☠️ MATAR
- Sin usuario real, sin motivación, sin urgencia
- Lo construido no es reutilizable
- → Aceptarlo. Archive del repo. Lección aprendida en una línea.

**Regla brutal:** si dudas entre A y D, probablemente es D.

---

## Paso 7 — Plan próximos 7 días (solo si decisión = A o B)

UNA entrega concreta esta semana. No 5. Una.

```
Esta semana entrego: ____________________
Cómo sé que está terminado: ____________________
Riesgo principal de no entregarlo: ____________________
```

Si no puedes llenar esto en 2 min → no tienes plan, tienes intenciones.

---

## Cierre del playbook

Antes de dejar al usuario, dale:

1. **Semáforo:** verde / amarillo / rojo
2. **Diagnóstico en 2-3 líneas:** "estás en X, problema principal es Y, decisión recomendada Z"
3. **Decisión tomada:** A/B/C/D
4. **Acción inmediata** (próximas 24h): ____

No le des soft feedback. Si está mal, decirlo. La amabilidad mal puesta cuesta semanas.
