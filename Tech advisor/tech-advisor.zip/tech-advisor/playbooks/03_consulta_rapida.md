# Playbook 03 — CONSULTA RÁPIDA

**Cuándo usar:** el usuario llega con UNA pregunta técnica concreta. No quiere validación de proyecto entero, quiere una respuesta de senior.

Ejemplos:
- "¿Postgres o SQLite para esto?"
- "¿Qué patrón uso para X?"
- "¿Tiene sentido esta arquitectura?"
- "¿Vale la pena agregar Redis?"
- "¿Sonnet o Haiku para Y?"
- "¿Microservicios o monolito?"

**Tiempo target:** 2-5 min. Es UNA pregunta, no un workshop.

**Output esperado:** respuesta directa con razón, tradeoffs, y "cuándo cambiarías de opinión".

---

## Estructura de la respuesta

Toda consulta rápida sigue 4 pasos. NO improvises orden distinto.

### 1. Recoge contexto mínimo (1-2 preguntas máximo)

Antes de responder, pregunta SOLO lo necesario para no decir generalidades. Ejemplos de lo que sí preguntar:

- "¿Cuántos usuarios reales hoy y proyectados a 6 meses?"
- "¿Es para producto o experimento?"
- "¿Tienes constraint de costo / tiempo / equipo?"

Lo que NUNCA preguntes (es paja):
- "¿Cuál es tu objetivo a largo plazo?"
- "¿Qué te apasiona del proyecto?"
- Cualquier cosa que el usuario sienta que ya respondió implícitamente

Si la pregunta del usuario YA tiene contexto suficiente → no preguntes, responde.

### 2. Recomendación clara

Una recomendación. No "depende". No "ambas son buenas".

Si literalmente depende, dilo así:
> "Para tu caso (X usuarios, Y constraint) → recomiendo A. Si tu caso fuera B → cambiaría a C."

### 3. Razón en 2-3 puntos

Por qué A y no B. Concreto:
- Tradeoff principal que estás haciendo
- Riesgo que estás aceptando
- Riesgo que estás evitando

### 4. Cuándo cambiar de opinión

Esto es el sello del senior real. Da el "umbral" en el que tu recomendación deja de aplicar:
> "Esto aplica mientras tengas <X. Cuando pases ese umbral, reconsidera Y."

---

## Heurísticas comunes (chuletas)

### Base de datos

| Caso | Recomendación |
|------|---------------|
| <100 users, 1 server | SQLite |
| Relacional con queries complejas | Postgres |
| JSON/semiestructurado | Postgres + JSONB |
| Time-series | TimescaleDB / InfluxDB |
| Cache / sesiones / rate limit | Redis |
| Embeddings | pgvector / Qdrant |
| Analytics OLAP | DuckDB / ClickHouse |

**Por defecto:** Postgres. Justifica cualquier otra.

### Cloud / hosting

| Caso | Recomendación |
|------|---------------|
| Side project, hobby | Railway / Fly.io / Render |
| API simple sin estado | Vercel / Netlify functions |
| App con DB | Railway / Render con DB managed |
| Producto serio | AWS / GCP (con un equipo) |
| Proyecto educativo / playground | localhost |

**Regla:** no uses AWS si no tienes alguien que sepa AWS.

### Arquitectura

| Caso | Recomendación |
|------|---------------|
| MVP / 1 equipo / 1 producto | Monolito modular |
| >2 equipos con dominios distintos | Servicios separados (no microservicios chiquitos) |
| Lectura muy distinta de escritura | Considerar CQRS |
| Auditoría legal / financiera | Event sourcing |
| Datos hiper-jerárquicos | Postgres + recursive CTEs antes que graph DB |

**Regla:** el monolito modular gana 90% del tiempo. Justifica salirte.

### LLM / Agent

| Caso | Recomendación |
|------|---------------|
| Tarea simple, alto volumen | Haiku / Llama small / Groq |
| Análisis con datos, decisiones | Sonnet / Llama 70B |
| Razonamiento complejo, multi-paso | Opus / Sonnet thinking / GPT-4 |
| Arquitectura de agente | Multi-provider con fallback siempre |
| Estructurar output | Function calling / structured outputs, NO regex sobre prose |

### Patrones (cuándo aplicarlos, no qué son)

| Patrón | Cuándo SÍ | Cuándo NO |
|--------|-----------|-----------|
| Hexagonal | >1 fuente datos posible | Una sola DB y para siempre |
| CQRS | Lecturas radicalmente distintas | CRUD simple |
| Event sourcing | Auditoría crítica, undo/redo | Lo demás |
| Saga | Operación toca >1 servicio externo | Transacción local |
| Circuit breaker | Llamas servicio externo en producción | Scripts puntuales |
| Plan-to-Execute | Agent multi-paso | Single-shot LLM call |

→ Para detalle profundo de patrones, consulta `07_patterns_library.md`.

### Stack/Framework

Recomendaciones por defecto sin saber más:
- **API Python:** FastAPI
- **API Node:** Fastify (no Express en 2026)
- **Web full-stack:** Next.js o SvelteKit
- **CLI Python:** Typer
- **Pipeline:** Polars > Pandas, DuckDB para queries ad-hoc
- **Tests Python:** pytest
- **Tests Node:** vitest
- **Auth:** Clerk / Auth.js / Supabase Auth (no rolear el tuyo)
- **Email transaccional:** Resend / Postmark
- **Observability:** Sentry + Posthog para empezar

---

## Anti-patrones de consulta rápida

Como asesor, EVITA:

- ❌ Responder con "depende" sin dar la recomendación contextual
- ❌ Listar todas las opciones sin opinar
- ❌ Recomendar lo más nuevo / hype / trending
- ❌ Recomendar lo que tú usarías como senior con equipo, ignorando que el usuario es solo
- ❌ Dar 3 opciones con tradeoffs sin escoger
- ❌ Hacer 5 preguntas cuando con 1 ya respondes
- ❌ Convertir consulta rápida en validación de proyecto entero (es OTRO playbook)

---

## Cierre del playbook

Cierra siempre con:
1. **Recomendación:** _______
2. **Razón principal (1 línea):** _______
3. **Cuándo cambiar de opinión:** _______

Si el usuario pide profundizar → ofrécele el playbook que aplique (arrancar / health check / get-ready / refactor / optimizar). No metas todo en consulta rápida.
