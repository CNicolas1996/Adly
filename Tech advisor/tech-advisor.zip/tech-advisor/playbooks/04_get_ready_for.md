# Playbook 04 — GET READY FOR (transición de fase)

**Cuándo usar:** el usuario quiere saltar a otra fase del proyecto. Las transiciones típicas:

- idea → MVP
- MVP → alpha (1-5 users de confianza)
- alpha → beta (10-50 users reales)
- beta → producción (público)
- producción → escala (>1000 users / enterprise)

**Tiempo target:** 15-20 min. Es la decisión más cara de equivocar — vale invertir bien.

**Output esperado:**
- Estado actual vs estado target
- Gap concreto (qué falta sí o sí)
- Decisión GO / NO-GO a la fase nueva
- Refactor roadmap si hay deuda crítica

---

## Paso 0 — Define las dos puntas

| Concepto | Respuesta |
|----------|-----------|
| Estado actual del proyecto | (idea / MVP / alpha / beta / prod / escala) |
| Estado al que quieres ir | (mismas opciones) |
| ¿Por qué quieres saltar AHORA? | _______ |
| ¿Qué pasa si esperas 2 semanas más? | _______ |

Si "por qué ahora" es ansiedad o presión externa sin sustento → probablemente no estás listo. Pero terminar el playbook igual.

---

## Paso 1 — Definiciones de cada fase (no son negociables)

### Idea
- Existe la idea, no hay código (o solo prototipo de papel)
- Sin usuarios

### MVP (Minimum Viable Product)
- Hay código que funciona end-to-end del flujo principal
- Tú lo usas. Nadie más todavía.
- Requisitos: el flujo crítico funciona en condiciones normales

### Alpha (1-5 users de confianza)
- Personas que conoces lo usan y reportan bugs
- Aceptan que se rompa
- Requisitos: estabilidad básica + canal de reporte de bugs + capacidad de actualizar rápido

### Beta (10-50 users reales)
- Usuarios fuera de tu círculo cercano
- Esperan funcionalidad completa
- Aceptan que aún haya bugs
- Requisitos: documentación, onboarding, monitoring básico, soporte

### Producción (público)
- Cualquiera puede usarlo
- Espera que funcione SIEMPRE
- Requisitos: SLO definido, monitoring + alertas, respuesta a incidentes, seguridad seria, backups

### Escala
- >1000 users concurrentes / contratos enterprise / SLA contractual
- Requisitos: arquitectura distribuida, on-call, SRE, compliance

---

## Paso 2 — Checklist por fase target

Carga SOLO el checklist de la fase a la que vas. No el resto.

### → MVP

Lo mínimo para decir "tengo MVP":

- [ ] Flujo principal funciona end-to-end (input → procesamiento → output)
- [ ] Lo puedes correr local con un solo comando
- [ ] README explica qué es y cómo correrlo
- [ ] Variables sensibles fuera del código
- [ ] Manejo básico de errores (no crashea con input vacío)
- [ ] Lo has usado tú mismo al menos 5 veces sin reabrir el código

Si te falta alguno → no es MVP, es prototipo. Termina antes de decirle a alguien.

### → Alpha (1-5 users de confianza)

Adicional a MVP:

#### Estabilidad
- [ ] Tests del flujo crítico (mínimo 3-5 tests, no 0 ni 50)
- [ ] Manejo de errores en frontera (input usuario + llamadas externas)
- [ ] Logs estructurados (no print) — necesitas saber qué pasó cuando reporten bug
- [ ] Has probado scenarios de fallo: input raro, servicio externo cae

#### Distribución
- [ ] Forma documentada de instalarlo / acceder
- [ ] Forma de actualizar rápido (push → user tiene la nueva versión)
- [ ] Canal de reporte de bugs (issue tracker, WhatsApp, email — algo)

#### Específico Agent (LLM)
- [ ] Multi-provider con fallback funcionando
- [ ] Logging de tokens IN/OUT por sesión
- [ ] Costo estimado por sesión sabido

### → Beta (10-50 users reales)

Adicional a Alpha:

#### Funcionalidad
- [ ] Features documentadas (no "está en el código, búscalo")
- [ ] Onboarding sin ti presente (instrucciones que un user nuevo entienda solo)
- [ ] Casos de uso comunes documentados con ejemplos

#### Operación
- [ ] Monitoring básico: ¿está corriendo? ¿hay errores? (1 dashboard mínimo)
- [ ] Alertas si algo crítico se cae
- [ ] CI corre tests en cada push
- [ ] CHANGELOG mantenido

#### Soporte
- [ ] Tienes capacidad de responder a 10-50 users en <48h
- [ ] FAQ de problemas comunes
- [ ] Forma de auto-diagnóstico (`tool doctor`, healthcheck)

#### Seguridad
- [ ] `pip audit` / `npm audit` corre y pasa
- [ ] HTTPS si hay tráfico de red
- [ ] Secretos en secret manager o env, nunca en código
- [ ] Logs no contienen credenciales / PII

### → Producción (público)

Adicional a Beta:

#### Resiliencia
- [ ] Rate limiting configurado (donde aplique)
- [ ] Circuit breaker en deps externas
- [ ] Timeouts en TODO (DB, HTTP, cache)
- [ ] Errores no exponen stack traces a usuarios
- [ ] Healthcheck endpoint
- [ ] Plan documentado de rollback

#### Operación seria
- [ ] SLO definido (ej: 99% uptime, p99 latencia < X)
- [ ] Métricas: request count, error rate, latencia, saturation
- [ ] Alertas accionables (no spam)
- [ ] Runbook para incidentes comunes
- [ ] Backups si hay datos persistentes
- [ ] Forma de redeployar sin downtime

#### Seguridad reforzada
- [ ] Auth + permisos testeados
- [ ] CSP, security headers (web)
- [ ] Validación input en TODA frontera
- [ ] Rate limit por user/IP
- [ ] Manejo prompt injection (si LLM)

#### Para Agent específicamente
- [ ] ReliabilityBench 3D pasa (consistency / robustness / fault tolerance)
- [ ] Chaos test sobrevivido (timeout, rate limit, response malformado)
- [ ] System prompt < 1500 tokens
- [ ] Validación output con schema
- [ ] Costo por user/día medido y alertable
- [ ] Manejo de prompt injection

### → Escala (>1000 users / enterprise)

Adicional a Producción. Acá ya entran cosas que no las haces solo:

- [ ] Arquitectura distribuida (load balancer + múltiples nodos)
- [ ] DB con replicación / sharding según necesidad
- [ ] Cache layer en serio (Redis cluster)
- [ ] CDN para assets
- [ ] On-call rotation (no puedes ser tú 24/7)
- [ ] Compliance según industria (GDPR, HIPAA, SOC2, etc.)
- [ ] SLA contractual con clientes
- [ ] Cell-based architecture (aislar fallos)
- [ ] Disaster recovery plan testeado

**Nota:** si vas a escala solo, repiénsalo. Esto no es de una persona.

---

## Paso 3 — Gap analysis

Marca lo del checklist target. Cuenta:

- **Pasaste >90% del checklist target** → ✅ GO con plan de cubrir el <10% restante en próximas semanas
- **Pasaste 70-90%** → ⚠️ GO con plan explícito de qué falta + cuándo
- **Pasaste 50-70%** → 🚨 NO-GO. Estás un escalón atrás. Quédate en fase actual y termina lo que falta.
- **Pasaste <50%** → 🚨🚨 NO-GO. Considera saltar 2 fases, no 1. Vuelve a MVP/alpha.

---

## Paso 4 — Refactor roadmap (si quedó deuda crítica)

Si pasas el GO pero hay items críticos sin cubrir, documenta:

```markdown
## Deuda crítica (resolver en X días, ANTES de seguir)
- [ ] Item: descripción, por qué es crítica, costo estimado de fix
## Deuda media (resolver en próximas Y semanas)
## Deuda menor (cuando haya tiempo)
```

Regla: mientras exista deuda crítica documentada, NO arranques features nuevas. Pagas deuda primero.

---

## Paso 5 — Decisión final

| Pregunta | Sí | No |
|----------|----|----|
| Pasaste el checklist de la fase target (≥70%)? | | |
| Tienes plan claro para la deuda restante? | | |
| Tienes capacidad de soportar el nuevo nivel de uso? | | |
| Sabes cómo te enteras si algo falla? | | |
| Tienes plan si toca rollback? | | |

**5 sí → GO.** Suelta a la fase target.
**4 sí + 1 no estratégico → GO con plan de mitigación documentado.**
**<4 sí → NO-GO.** Resuelve antes.

---

## Cierre del playbook

Antes de dejar al usuario:

1. **Estado actual real:** _______
2. **Fase target:** _______
3. **Gap principal:** _______
4. **Decisión:** GO / GO con condiciones / NO-GO
5. **Acción inmediata (próxima semana):** _______

Si la decisión es NO-GO, no le suavices. Decirle "casi" cuesta meses cuando lance algo medio listo y queme usuarios.

---

## Mantra

> "Production no es que funcione en tu máquina. Es que funcione bajo presión, a escala, en condiciones que no anticipaste, y que cuando falle (porque va a fallar), tengas cómo enterarte y arreglar."

Aplica también para alpha y beta, escalado.
