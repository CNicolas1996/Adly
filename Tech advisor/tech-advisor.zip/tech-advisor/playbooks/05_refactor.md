# Playbook 05 — REFACTOR

**Cuándo usar:** el usuario dice "esto está feo", "el código está enredado", "ayúdame a limpiar", "hay que refactorizar", "ya no entiendo mi propio código".

**Tiempo target:** 15-20 min para el plan. El refactor en sí toma horas/días, pero el playbook es para PLANEARLO bien.

**Output esperado:**
- Diagnóstico de qué está mal y por qué
- Decisión: refactor parcial / refactor grande / rewrite / dejar tal cual
- Plan ordenado de cambios (no big-bang)
- Criterio de éxito (cómo sabes que el refactor sirvió)

---

## Paso 0 — Filtro brutal antes de refactorizar

Refactor mal hecho rompe todo. Antes de tocar nada:

1. **¿Hay tests que cubran lo que vas a refactorizar?** Si NO → primero escribe tests, después refactoriza. NUNCA al revés.
2. **¿Esta semana tienes que entregar features?** Si SÍ → refactor parcial mínimo. No grande.
3. **¿El código actual funciona en producción?** Si SÍ → refactor incremental, no rewrite.
4. **¿Estás aburrido y por eso quieres refactorizar?** Si SÍ → llámalo. Refactorizar para procrastinar features es vibe coding disfrazado.
5. **¿Refactorizar este pedazo desbloquea algo concreto?** Si NO → puede esperar.

Si fallas el filtro → no refactorices ahora. Anota la deuda en `REFACTOR.md` y sigue.

---

## Paso 1 — Diagnóstico ¿qué está mal exactamente?

Marca todas las que apliquen al código que quieres refactorizar:

### Smells de estructura
- [ ] Funciones >50 líneas
- [ ] Funciones que hacen >1 cosa (puedes describirlas con "y")
- [ ] Clases con >7 métodos públicos
- [ ] Archivos con >500 líneas
- [ ] Carpeta `utils/` o `helpers/` con cosas no relacionadas
- [ ] Lógica de negocio mezclada con I/O (DB, HTTP, file system)
- [ ] Duplicación obvia (mismo bloque 3+ veces)
- [ ] Acoplamiento alto: cambiar A obliga a tocar B, C, D

### Smells de naming
- [ ] Variables `x`, `data`, `result`, `temp` sin contexto
- [ ] Funciones `process_data`, `do_stuff`, `handle`
- [ ] Magic numbers (`if x > 42`)
- [ ] Magic strings (`if status == "ACTIVE_VALIDATED_NEW"`)
- [ ] Nombres que mienten (función `get_user` que también la guarda en DB)

### Smells de errores
- [ ] `try: ... except: pass` (errores silenciosos)
- [ ] `except Exception` genérico en todas partes
- [ ] Errores sin contexto (`raise ValueError("error")`)
- [ ] Validación duplicada en 3 capas o ausente

### Smells de testing
- [ ] No hay tests
- [ ] Tests que mockean todo y no prueban nada
- [ ] Tests que rompen cuando cambias implementación (acoplados a internals)

### Smells de configuración
- [ ] Hardcoded paths / URLs / credenciales
- [ ] Config dispersa en 5 lugares distintos
- [ ] Variables de entorno sin documentar

**Conteo:**
- 1-3 smells → refactor parcial focalizado
- 4-7 smells → refactor estructural
- 8+ smells → considera si vale la pena, o si es rewrite

---

## Paso 2 — Decisión: ¿qué tipo de refactor?

### A. Refactor parcial (1-3 smells aislados)
- **Cuándo:** smells localizados en 1-2 archivos
- **Estrategia:** cambios pequeños, commit por cambio, tests verdes en cada commit
- **Tiempo:** horas
- **Ejemplo:** renombrar variables, extraer función, eliminar duplicación

### B. Refactor estructural (4-7 smells, módulo entero)
- **Cuándo:** un módulo completo está mal estructurado
- **Estrategia:** Strangler Fig — código viejo y nuevo coexisten, migras gradual
- **Tiempo:** días/semana
- **Ejemplo:** separar lógica de I/O, introducir patrón Hexagonal, dividir clase god

### C. Rewrite (>7 smells, código irreparable)
- **Cuándo:** el código es más caro mantener que reescribir
- **Estrategia:** especificar qué hace ANTES, escribir tests de contrato, reescribir ahí, switch atómico
- **Tiempo:** semanas/meses
- **⚠️ Regla:** rewrites mueren más de lo que viven. Si dudas → no rewrite, refactor estructural.

### D. Dejar tal cual
- **Cuándo:** funciona, no se va a tocar más, no es la pieza crítica
- **Estrategia:** anotarlo en REFACTOR.md, seguir
- **Recordatorio:** "código feo que funciona" > "código bonito que no entregaste"

---

## Paso 3 — Plan de refactor (si decisión es A, B o C)

### Para refactor parcial (A)

Lista los cambios uno por uno, ordenados por riesgo (menos riesgo primero):

```
1. [renombrar X → Y] — sin cambio funcional, riesgo 0
2. [extraer función Z] — sin cambio funcional, riesgo bajo
3. [reorganizar imports] — sin cambio funcional, riesgo 0
4. [eliminar duplicación A] — sin cambio funcional, riesgo medio
```

Reglas:
- **Un commit = un cambio.** No mezcles.
- **Tests verdes en cada commit.** Si rompen, paras.
- **No agregues funcionalidad.** Refactor ≠ feature.

### Para refactor estructural (B) — Strangler Fig

```
1. Identifica la frontera nueva (interface, módulo nuevo)
2. Crea el módulo nuevo, vacío con interface clara
3. Implementa UNA pieza en el nuevo, mantén la vieja
4. Cambia 1 caller a usar el nuevo
5. Verifica que todo sigue funcionando
6. Migra siguiente caller
7. Repite hasta que no quede nada usando el viejo
8. Borra el viejo
```

Plan típico de 1-2 semanas.

### Para rewrite (C)

```
1. Documenta el comportamiento actual (specs)
2. Escribe tests de contrato (input → output esperado)
3. Implementa nuevo en paralelo, sin tocar el viejo
4. Corre tests de contrato contra los DOS (deben dar igual output)
5. Switch atómico: cambia el routing al nuevo
6. Mantén el viejo 1-2 sprints como fallback
7. Borra el viejo
```

⚠️ Si los tests de contrato no se pueden escribir → no entiendes lo viejo. NO rewrite.

---

## Paso 4 — Definir éxito (criterio de salida)

Antes de empezar, define qué significa "terminé":

| Aspecto | Criterio medible |
|---------|------------------|
| Estructura | "Función X ahora hace solo Y" |
| Naming | "Ningún nombre genérico (data, x, temp) en módulo Z" |
| Errores | "0 try/except sin handling específico en módulo Z" |
| Tests | "Cobertura del módulo refactorizado >70%" |
| Performance | "Igual o mejor latencia que antes" (si aplica) |

Si no puedes definir el criterio → no estás refactorizando, estás "mejorando".

---

## Paso 5 — Anti-patrones de refactor

NO hagas:

- ❌ Refactor + features en la misma rama
- ❌ Refactor sin tests previos
- ❌ Refactor "porque me gustaría más así"
- ❌ Big-bang refactor (cambiar 30 archivos en 1 commit)
- ❌ Refactor para usar la tech nueva que aprendiste
- ❌ Refactor sin medir si el resultado es mejor (especialmente performance)
- ❌ Refactor siguiendo blog post de Twitter sin pensar si aplica
- ❌ Borrar código viejo antes de validar que el nuevo funciona en prod
- ❌ "Quick refactor" que termina en 3 semanas

---

## Paso 6 — Patrones de refactor más comunes (chuletas)

### Extraer función
**Cuándo:** función >30 líneas, o un bloque tiene su propio nombre conceptual
**Cómo:** identifica el bloque, extrae con nombre claro, deja la original llamando

### Reemplazar condicionales con polimorfismo
**Cuándo:** if/elif/else gigante chequeando tipos
**Cómo:** cada caso → clase con método común. Strategy pattern.

### Introducir parameter object
**Cuándo:** función con >5 parámetros
**Cómo:** agrupa parámetros relacionados en un objeto / dict / dataclass

### Separar I/O de lógica (Hexagonal lite)
**Cuándo:** lógica de negocio mezclada con DB / HTTP / archivos
**Cómo:** lógica pura recibe data ya cargada, I/O en módulo aparte

### Reemplazar magic value con constante
**Cuándo:** números o strings sueltos
**Cómo:** `TIMEOUT_SECONDS = 30` arriba del archivo, usa la constante

### Inline (lo opuesto a extraer)
**Cuándo:** función trivial usada 1 sola vez con nombre que no agrega claridad
**Cómo:** mete el código donde se llama, borra la función

---

## Cierre del playbook

Antes de dejar al usuario, dale:

1. **Diagnóstico:** _______ (cuántos smells, qué tipo)
2. **Tipo de refactor:** A / B / C / D
3. **Plan concreto:** lista de cambios ordenados
4. **Criterio de éxito:** _______
5. **Tiempo estimado realista:** _______

Si el plan termina siendo "vamos a reescribir todo Adly" en una sesión → llámalo. Probablemente es C cuando debería ser B.
