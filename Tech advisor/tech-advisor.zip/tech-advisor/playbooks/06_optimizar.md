# Playbook 06 — OPTIMIZAR

**Cuándo usar:** el usuario dice "está lento", "está caro", "consume mucho", "no escala", "pierdo plata en LLM calls", "se cae con N usuarios".

**Tiempo target:** 10-15 min para diagnóstico + plan. Optimizar antes de medir es el peor anti-patrón en software.

**Output esperado:**
- Métrica del problema (no "se siente lento", número concreto)
- Causa raíz identificada (no asumida)
- Plan de optimización ordenado por ROI
- Criterio de éxito medible

---

## Paso 0 — Regla de oro

> **"Premature optimization is the root of all evil"** — Knuth

Y su corolario menos famoso pero más importante:
> **"Optimization without measurement is just guessing."**

Antes de optimizar nada, EXIGE medición. Si el usuario dice "está lento" sin número, no aceptes. Pídelo:
- ¿Cuántos ms / segundos?
- ¿Bajo qué carga?
- ¿Comparado con qué baseline?

Si no hay medición → primer paso es medir, no optimizar.

---

## Paso 1 — Identificar tipo de problema

| Tipo | Síntoma | Métrica relevante |
|------|---------|-------------------|
| **Latencia** | "Una request tarda mucho" | p50, p95, p99 latencia (ms) |
| **Throughput** | "No aguanta N requests/seg" | requests/segundo, errors/seg |
| **Costo** | "Pago mucho en infra/LLM" | $/mes, $/request, $/user |
| **Memoria** | "Crece y se cae" | MB usados, growth rate |
| **CPU** | "Sat al 100% con poco" | % CPU, queue depth |
| **Disco/IO** | "Se traba con datos grandes" | IOPS, MB/s |
| **Red** | "Network es el cuello" | bandwidth, latency entre servicios |

El usuario suele venir con uno. Pero a veces son varios mezclados — preguntar.

---

## Paso 2 — Medir antes de tocar (BASELINE)

NO optimices sin baseline. Setup mínimo según tipo:

### Latencia (API / función)
```python
import time
start = time.perf_counter()
result = mi_funcion(...)
print(f"{time.perf_counter() - start:.3f}s")
```
O mejor: profiler (`cProfile`, `py-spy` para Python; `clinic.js` para Node).

### Costo (LLM specifically)
- Loggea tokens IN / OUT por cada call
- Calcula $/sesión
- Identifica los TOP 10 calls más caros
- Mira: ¿son necesarios? ¿caché? ¿modelo más barato?

### Memoria
- Python: `tracemalloc`, `memory_profiler`
- Node: `process.memoryUsage()`, heap snapshots
- Mira: crece linealmente con tiempo? con requests? con datos?

### CPU
- `htop` / `top` durante la carga
- profiler de CPU (`py-spy`, `Node --prof`)
- Identifica los hot paths

### Throughput
- `wrk`, `k6`, `locust` para load testing
- Mide: a partir de cuántos rps degrada
- Busca el bottleneck (CPU, DB, red)

**Regla:** sin baseline, no procedas. La sesión termina acá.

---

## Paso 3 — Identificar causa raíz

Las causas comunes ordenadas por probabilidad (Pareto):

### Top 5 causas de latencia (cubren 80% de casos)
1. **Llamadas externas sin caché** — APIs, DBs, LLMs
2. **N+1 queries en DB** — loop hace una query por iteración
3. **Procesamiento sincrónico de cosas paralelizables** — debería ser async
4. **JSON / serialización masiva** — payloads gigantes
5. **No índices en DB** — full table scans

### Top 5 causas de costo LLM
1. **System prompt muy largo** — pagas en cada call
2. **Modelo overpowered para tarea** — usar Opus para "hola"
3. **Sin caché semántico** — queries similares cuestan lo mismo
4. **Retries sin límite** — falla y reintenta sin tope
5. **Falta de structured output** — LLM responde de más

### Top 5 causas de memoria
1. **Leaks por listeners / handlers no removidos**
2. **Estructuras que crecen sin bound** — caches sin eviction
3. **Cargar todo en memoria** vs streaming
4. **Closures que capturan más de lo necesario**
5. **Conexiones no cerradas** — DB pools, file handles

### Top 5 causas de throughput
1. **DB es el cuello** — connection pool, slow queries
2. **GIL en Python (si es CPU-bound)** — workers, async no ayuda
3. **Sin connection pooling** — abrir/cerrar conexión por request
4. **Llamadas síncronas a servicios externos** — bloquean worker
5. **Locks innecesarios** — contención

**Diagnóstico:** correlaciona síntoma con causa probable y verifica con medición.

---

## Paso 4 — Plan ordenado por ROI

NO optimices todo. Aplica Pareto: 20% de cambios = 80% de mejora.

Ordena las optimizaciones posibles:

| Optimización | Ganancia esperada | Costo de implementar | ROI |
|--------------|-------------------|----------------------|-----|
| (cambio 1)   | 50% reducción latencia | 2 horas | ALTO |
| (cambio 2)   | 20% reducción costo | 1 día | MEDIO |
| (cambio 3)   | 5% mejora memoria | 3 días | BAJO |

**Regla:** ataca solo las de ROI ALTO primero. Mide después de cada una. Para cuando ya cumpliste el target.

---

## Paso 5 — Recetas comunes (por tipo)

### Latencia: Caché
- **In-memory (LRU):** datos pequeños, 1 proceso
- **Redis:** compartido entre procesos, datos medianos
- **CDN:** assets estáticos, respuestas idempotentes
- **HTTP cache headers:** del lado cliente
- **Semantic cache (LLM):** queries similares por embedding

### Latencia: Async / paralelismo
- I/O bound → async (asyncio, promises)
- CPU bound → workers (multiprocessing, worker threads)
- N llamadas independientes → batch / parallel

### Latencia: DB
- Agregar índice donde haya WHERE/ORDER BY/JOIN frecuente
- Eliminar N+1 con eager loading / JOINs
- Paginación en lugar de cargar todo
- Read replicas para lecturas pesadas
- DB pool con tamaño correcto (no 1, no 1000)

### Costo LLM
- **Reducir system prompt** — cada token cuenta × N calls
- **Routing por complejidad** — Haiku para simple, Sonnet/Opus para complejo
- **Caché semántico** — queries similares → respuesta guardada
- **Structured output** — function calling, no parseando prose
- **Stop sequences** — corta cuando ya tienes lo necesario
- **Batch processing** — agrupa requests si la API lo permite
- **Self-hosted para volumen alto** — Llama, Mistral en infra propia

### Memoria
- Streaming en lugar de cargar todo (lectura archivos, queries DB)
- Generadores en lugar de listas (Python)
- Eviction en caches (LRU con tamaño máximo)
- Cerrar conexiones explícitamente (context managers)
- Eliminar closures innecesarios

### Throughput
- Connection pooling (DB, HTTP clients)
- Workers según núcleos
- Async para I/O bound
- Queue para desacoplar request de procesamiento
- Rate limiting upstream para no sobrecargar

---

## Paso 6 — Criterio de éxito (target)

Antes de empezar, define el target:

```
Métrica: ____ (ej: p95 latencia API endpoint X)
Baseline actual: ____ (ej: 800ms)
Target: ____ (ej: <200ms)
Cómo mido: ____ (herramienta concreta)
```

**Regla:** target debe ser realista. Pasar de 800ms a 50ms quizá no es posible. Pasar a 200ms sí.

Si llegas al target → para. No sigas optimizando "porque sí".

---

## Paso 7 — Anti-patrones de optimización

NO hagas:

- ❌ Optimizar sin medir baseline
- ❌ Optimizar sin medir si mejoró
- ❌ Optimizar lo que no es bottleneck (es invisible)
- ❌ Microoptimizaciones (sustituir `for` por list comprehension cuando el bottleneck es una API call)
- ❌ Cachear sin invalidación clara (caches obsoletos = bugs invisibles)
- ❌ Async para CPU-bound (no ayuda, complica)
- ❌ Paralelismo cuando hay shared state (race conditions)
- ❌ Reescribir en Rust/Go/lo-que-sea sin medir si vale la pena
- ❌ Optimizar para escala que no tienes (1000 users hipotéticos cuando tienes 5 reales)
- ❌ "Premature optimization" sin profiling

---

## Paso 8 — Específico para Adly (caso de referencia)

Como ejemplo aplicado:

| Problema | Causa probable | Recetas |
|----------|---------------|---------|
| System prompt 2700 tokens | Verbosidad acumulada | Recortar, deduplicar, target 1200 |
| Costo alto en LLM | Modelo único para todo | Multi-provider routing por complejidad |
| Latencia en queries repetidas | Sin caché | Semantic cache con embeddings |
| Falla cuando Groq cae | Sin circuit breaker | Circuit breaker + exponential backoff |
| Sheets API lenta | Carga todo cada vez | Cache de Sheets data con TTL |

ROI ordenado para Adly:
1. **System prompt 2700 → 1200** — 30 min trabajo, ahorra 50% tokens en cada call. ROI absurdo.
2. **Routing por complejidad** — 2-3 horas, ahorra 40-60% costo. Alto ROI.
3. **Caché de Sheets** — 1-2 horas, mejora latencia notable. Medio-alto ROI.
4. **Circuit breaker** — 2-3 horas, no mejora performance pero reduce failures. Diferente eje.
5. **Caché semántico** — 1 día, ahorra 30-50% en queries repetidas. Medio ROI inicial.

---

## Cierre del playbook

Antes de dejar al usuario, dale:

1. **Tipo de problema:** _______
2. **Baseline medido:** _______ (rechazar si dice "no medí")
3. **Causa raíz identificada:** _______
4. **Top 1-2 optimizaciones por ROI:** _______
5. **Target medible:** _______
6. **Cómo verificará si funcionó:** _______

Si el usuario quiere implementar 5 optimizaciones de una → llámalo. Una a la vez. Mide entre cada una. Si no, no sabes cuál sirvió.
