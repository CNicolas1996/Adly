# 07 — PATTERNS LIBRARY (referencia)

**No es un playbook.** Es referencia técnica que los demás playbooks consultan.

**Cuándo se carga:** cuando un playbook (típicamente `01_arrancar` o `03_consulta_rapida`) te pide buscar info específica de un arquetipo.

**No leas esto completo.** Salta directo al arquetipo o sección que necesitas.

---

## Tabla de contenido

1. [Patrones cross-arquetipo](#patrones-cross-arquetipo)
2. [Agent (LLM)](#agent-llm)
3. [CLI](#cli)
4. [API/Servicio](#apiservicio)
5. [Pipeline](#pipeline)
6. [Web App](#web-app)
7. [Game](#game)
8. [Decisiones de base de datos](#decisiones-de-base-de-datos)
9. [Anti-patrones (señales de vibe coding)](#anti-patrones)
10. [MVA — Minimum Viable Architecture](#mva--minimum-viable-architecture)

---

## Patrones cross-arquetipo

Aplican a casi todo. No los inventes proyecto por proyecto.

### Hexagonal (Ports & Adapters)
- **Qué:** lógica de negocio NO conoce I/O externo. Conectores son intercambiables.
- **Cuándo:** cuando hay >1 fuente de datos posible (DB local + remota, API + mock, etc.)
- **Ejemplo Adly:** `BaseConnector` con `SheetsConnector` y `MockConnector` — la lógica de métricas no sabe de dónde vienen los datos.

### SOLID (lo que importa de verdad)
- **SRP (Single Responsibility):** una clase, una razón para cambiar. Si describes la clase con "y" → divídela.
- **DI (Dependency Injection):** pasa dependencias por constructor, no las instancies adentro. Hace testing trivial.
- Los otros 3 (OCP, LSP, ISP) aplican menos en proyectos pequeños. No los fuerces.

### Configuración por capas
Orden de prioridad (mayor gana):
1. CLI args / runtime
2. Variables de entorno (`.env`)
3. Archivo de config (`config.yaml`)
4. Defaults en código

Nunca hardcodees URLs, credenciales, paths. Nunca.

### Manejo de errores
- **Falla rápido en frontera:** valida input apenas entra (Pydantic, zod, etc.)
- **Captura específica, no genérica:** `except Exception` es código muerto al debugging
- **Excepciones tienen contexto:** `raise ValueError(f"X falló porque {detalle}")`, no `raise ValueError("error")`
- **Logs estructurados:** JSON o key=value, no strings concatenados

### Cell-based architecture (cuando escala)
- **Qué:** el sistema se divide en "células" auto-contenidas que pueden fallar aisladamente.
- **Cuándo:** cuando ya tienes >100 usuarios o necesitas alta disponibilidad.
- **NO en MVP.** Es premature optimization.

---

## Agent (LLM)

### 1. Multi-Provider Routing
**Qué:** distintos modelos para distintas complejidades de query.

```
Query simple ("hola", "qué métricas hay") → Haiku / Llama-Free / Groq
Query media (análisis con datos) → Sonnet / Llama 70B
Query compleja (decisión multi-paso) → Opus / Claude / GPT-4
```

**Ahorro real:** 60-80% costo si lo aplicas bien.

### 2. Resilient Fallback
**Qué:** si provider primario falla → siguiente automáticamente.

```python
providers = [Groq, Anthropic, OpenAI, Together]
for provider in providers:
    try:
        return provider.call(prompt, timeout=30)
    except (RateLimitError, TimeoutError, APIError) as e:
        log_failure(provider, e)
        continue
raise AllProvidersDown()
```

**Componentes:**
- **Circuit breaker:** si provider falla N veces en T tiempo → no lo intentes por X minutos
- **Exponential backoff:** retry con delay creciente (1s, 2s, 4s, 8s)
- **Timeout explícito:** SIEMPRE.

### 3. Plan-to-Execute (P-t-E)
**Qué:** primero planifica TODA la respuesta, luego ejecuta. Evita decisiones a medio camino.

**Cuándo:** queries multi-paso ("compárame ROAS de marzo vs abril y dame 3 acciones" = plan = [extraer marzo, extraer abril, comparar, generar acciones]).

### 4. Token efficiency / system prompt minimalism
**Qué:** system prompts < 1500 tokens (objetivo: 900-1200).

**Reglas:**
- Una instrucción, una línea
- No repitas reglas con sinónimos
- Ejemplos solo si los necesita el modelo
- Versiona los prompts (git, no en docstrings)

### 5. Semantic caching
**Qué:** queries similares (no idénticas) reutilizan respuestas anteriores.

**Cuándo:** queries de usuarios repetitivas. Ahorra 30-50% en producción.

### 6. Orchestrator-Worker
**Qué:** un orquestador central decide qué agentes llamar. Workers especializados ejecutan.

**Cuándo:** cuando tienes >2 capacidades distintas. NO en MVP de un solo agente.

### 7. MCP (Model Context Protocol)
**Qué:** estándar para que agentes hablen con herramientas externas (Anthropic).

**Cuándo:** cuando integras tu agente con sistemas externos estandarizados. NO en v1.

### 8. Function calling / Tool use
**Reglas:**
- Tool definitions claras y minimalistas
- Validación post-call (el LLM se equivoca con tipos)
- Un tool = una acción atómica
- No expongas tools peligrosos sin sandbox

### Testing de agentes — ReliabilityBench 3D

No basta pass@1. Mide:

1. **Consistency:** mismo input 5 veces → ¿salidas similares semánticamente?
2. **Robustness:** input malformado / raro → ¿degrada gracefully o explota?
3. **Fault tolerance:** provider cae / rate limit / response malformado → ¿el sistema sigue funcionando?

Métricas adicionales:
- **RDC (Response Drift Coefficient):** cuánto varía a queries equivalentes
- **VAF (Validation Accuracy Floor):** % respuestas que pasan validación schema
- **GDS (Goal Drift Score):** cuánto se aleja de la intención original
- **MOP (Mean Operations per Plan):** complejidad del plan generado

### Chaos testing para agentes

Simula:
- Timeout del provider
- Rate limit response (429)
- Response truncado
- Schema drift (campo cambia de tipo)
- JSON malformado
- Latencia extrema (10s, 30s)

Si tu agente sobrevive estos 6 sin caerse → está production-grade.

---

## CLI

### Patrones específicos

- **Comando principal + subcomandos:** `adly query`, no `adly --query`
- **Output dual:** human-readable por default, `--json` para piping
- **Stdin friendly:** `cat data.csv | mycli process` debe funcionar
- **Exit codes:** 0 éxito, 1 error genérico, 2 misuse, otros para errores específicos
- **Progress bars solo si TTY:** `if sys.stdout.isatty(): show_progress()`

### Strategy para conectores
Adly aplica esto: `BaseConnector` interface → implementaciones intercambiables.

### Onboarding flow
- Primera corrida → setup wizard (no falla con "missing config")
- Config en `~/.config/<tool>/` (XDG standard) o `%APPDATA%` en Windows
- `<tool> --version`, `<tool> --help`, `<tool> doctor` (diagnostica setup)

### Testing CLI
- snapshot del output (golden files)
- mock de I/O externo (no llames APIs reales en tests)
- test de exit codes

---

## API/Servicio

### Patrones obligatorios

- **Validación con schemas:** Pydantic / zod / valibot. Nunca confíes en input.
- **DI con frameworks:** FastAPI `Depends`, NestJS providers
- **Repositorio para DB:** la lógica de negocio NO sabe SQL. Pasa por repos.
- **Service layer:** rutas → services → repos. No metas lógica en rutas.

### Resiliencia

- **Rate limiting:** redis + sliding window. Por IP y por user.
- **Circuit breaker para deps externas:** si llamas a otra API y cae → no la sigas llamando.
- **Bulkhead:** pool de conexiones DB separado por tipo de operación.
- **Timeouts en TODO:** DB, HTTP, cache. Sin excepción.

### CQRS (cuándo)
**Qué:** lecturas y escrituras tienen modelos separados.
**Cuándo:** cuando lecturas son MUY distintas a escrituras (reportes complejos vs CRUD). NO en MVP.

### Event Sourcing
**Qué:** guardas eventos, no estado.
**Cuándo:** auditoría crítica, undo/redo, sistemas financieros. NO si no lo necesitas.

### Saga pattern
**Qué:** transacción distribuida con compensación.
**Cuándo:** cuando una operación toca >1 servicio externo y necesitas atomicidad lógica.

### Testing API
- **Unit:** services y validators
- **Integration:** rutas con DB de testing (no mock — DB real)
- **Contract:** si exposes API a otros, contract tests
- **Load:** mínimo locust o k6 antes de producción

---

## Pipeline

### Patrones obligatorios

- **Idempotencia:** correr 2 veces = mismo resultado final
- **Checkpointing:** si falla en paso N, retoma en N (no desde 0)
- **Validación schema:** entrada Y salida. Pandera, Pydantic, dbt tests.
- **Dead-letter queue:** registros que fallan van a tabla aparte, no rompen el run

### Strangler Fig
**Cuándo:** cuando heredas un monolito ETL y no puedes reescribir todo.

### Testing pipeline
- Test con dataset pequeño conocido (golden dataset)
- Test de schema drift (qué pasa si llega columna nueva, falta una, cambia tipo)
- Test de idempotencia (correr 2 veces, comparar)

---

## Web App

### Patrones obligatorios

- **Server-side validation:** SIEMPRE. Client-side es UX, no seguridad.
- **Auth desde día 1 si hay datos sensibles**
- **Boundary clara server/client**
- **Error boundaries:** captura errores de UI
- **Loading states reales:** skeleton screens > spinners

### Performance
- **Lazy load:** rutas y componentes pesados
- **Image optimization:** next/image, formatos modernos (avif, webp)
- **Bundle size budget:** < 200kb JS inicial

### Testing web
- E2E con Playwright para el flujo crítico
- Component tests solo para lógica compleja
- Visual regression si UI es crítica

---

## Game

### Patrones obligatorios

- **Game loop fijo:** `while running: input → update → render`
- **Delta time:** todo movimiento basado en `delta_time`
- **Separation of concerns:** input system, physics, render — separados
- **ECS si entidades > 10:** Entity-Component-System escala mejor que OOP

### Testing game
- Unit para lógica (colisiones, scoring)
- Smoke test del game loop a distintos FPS
- Manual para feel

---

## Decisiones de base de datos

| Caso | DB recomendada |
|------|---------------|
| App pequeña, 1 server, < 100 usuarios | SQLite |
| App con relaciones, queries complejas | PostgreSQL |
| Datos jerárquicos, queries flexibles | PostgreSQL + JSONB |
| Time-series (métricas, logs) | TimescaleDB / InfluxDB |
| Cache, sesiones, rate limit | Redis |
| Búsqueda full-text seria | Postgres (tsvector) o Meilisearch |
| Embeddings / vector search | pgvector / Qdrant |
| Analytics OLAP, archivos grandes | DuckDB / ClickHouse |
| Documentos sin schema fijo | PostgreSQL + JSONB |

**Regla de oro:** Postgres por default. Justifica cualquier otra cosa.

---

## Anti-patrones (señales de vibe coding)

Si haces alguna → para y reconsidera.

- ❌ Empezar por el frontend sin saber qué hace el backend
- ❌ Instalar 5 librerías "por si acaso" antes de escribir lógica
- ❌ Crear `utils.py` en el primer commit (basurero futuro)
- ❌ `try: ... except: pass` (errores silenciosos = bugs eternos)
- ❌ Hardcodear credenciales "solo para probar"
- ❌ Commits sin mensaje real ("wip", "fix", "stuff")
- ❌ Copy-paste de Stack Overflow / Claude sin entender
- ❌ "Después lo refactoreo"
- ❌ Branch única `main`, push directo, sin tests
- ❌ Reescribir lo que ya funciona porque "no me gusta cómo se ve"
- ❌ Agregar abstracciones para casos hipotéticos
- ❌ Optimizar performance antes de tener performance medida
- ❌ Microservicios para 1 usuario
- ❌ Kubernetes para un script
- ❌ Aprender tech nueva mientras construyes algo serio

**El más importante:** construir la herramienta para construir herramientas, en vez de la herramienta. Si llevas más tiempo en infra que en producto → estás en efecto Chavo.

---

## MVA — Minimum Viable Architecture

Para MVP:
- **NO:** microservicios, Kubernetes, CQRS, event sourcing, multi-region, GraphQL federation
- **SÍ:** monolito modular, Postgres, una caja, deploy simple, observabilidad básica (logs + 1 dashboard)

Cuándo agregar cada cosa:
- **Cache:** cuando midas que algo es lento
- **Queue:** cuando tengas operaciones async reales (>5s)
- **Microservicios:** cuando equipos distintos los necesiten (>2 equipos)
- **K8s:** cuando tengas >5 servicios productivos
- **Multi-region:** cuando tengas usuarios pidiéndolo en regiones distintas

Regla: agregar complejidad solo cuando el dolor de NO tenerla > dolor de mantenerla.
